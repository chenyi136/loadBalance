package com.aliware.tianchi;

import com.google.gson.JsonObject;
import org.apache.dubbo.common.logger.LoggerFactory;
import org.apache.dubbo.config.ProtocolConfig;
import org.apache.dubbo.config.context.ConfigManager;
import org.apache.dubbo.rpc.listener.CallbackListener;
import org.apache.dubbo.rpc.service.CallbackService;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;


/**
 * @author daofeng.xjf
 * <p>
 * 服务端回调服务
 * 可选接口
 * 用户可以基于此服务，实现服务端向客户端动态推送的功能
 */
public class CallbackServiceImpl implements CallbackService {

    /**
     * key: listener type
     * value: callback listener
     *
     */
    public static Logger LOG = (Logger) LoggerFactory.getLogger(CallbackServiceImpl.class);

    public static Runtime runtime= Runtime.getRuntime();

    private static final Map<String, CallbackListener> listeners = new ConcurrentHashMap<>();

//  providerConfig 信息

    public static int poolSize;

    public static int coreThreads;

    public static int accepts;

    public static int payLoad;

    public static int port;

// jvm 运行时信息
    public static long freeMemory;

    public static  long maxMemory;

    public static  long totalMemory;

    public static int avaliableProcessors;


    private Timer timer = new Timer();



    public CallbackServiceImpl() {

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Map<String, ProtocolConfig> map = ConfigManager.getInstance().getProtocols();
                if (null != map && map.size() > 0) {
                    ProtocolConfig config = map.values().iterator().next();
                    port = config.getPort();
                    coreThreads = config.getCorethreads();
                    accepts = config.getAccepts();
                    poolSize = config.getThreads();
                    payLoad = config.getPayload();
                }
                freeMemory = runtime.freeMemory();
                totalMemory = runtime.totalMemory();
                maxMemory = runtime.maxMemory();
                avaliableProcessors = runtime.availableProcessors();
            }

        }, 0, 500);
    }

    @Override
    public void addListener(String key, CallbackListener listener) {
        listeners.put(key, listener);
        listener.receiveServerMsg(providerInfomation().toString());
    }


    private JsonObject providerInfomation(){
       JsonObject jsonObject=new JsonObject();
       JsonObject info=new JsonObject();
//       jsonObject.addProperty("port", port);
       jsonObject.addProperty("poolSize", poolSize);
       jsonObject.addProperty("coreThreads", coreThreads);
       jsonObject.addProperty("accepts", accepts);
       jsonObject.addProperty("payLoad",payLoad);
       jsonObject.addProperty("freeMemory",freeMemory);
       jsonObject.addProperty("totalMemory", totalMemory);
       jsonObject.addProperty("maxMemory",maxMemory);
       jsonObject.addProperty("avaliableProcessors",avaliableProcessors);

       info.addProperty("port",port);
       info.addProperty("info", String.valueOf(jsonObject));
       return info;

   }


}
