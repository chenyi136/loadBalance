package com.aliware.tianchi;

import com.google.gson.JsonObject;
import org.apache.dubbo.common.URL;
import org.apache.dubbo.rpc.Invocation;
import org.apache.dubbo.rpc.Invoker;
import org.apache.dubbo.rpc.RpcException;
import org.apache.dubbo.rpc.cluster.LoadBalance;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author daofeng.xjf
 *
 * 负载均衡扩展接口
 * 必选接口，核心接口
 * 此类可以修改实现，不可以移动类或者修改包名
 * 选手需要基于此类实现自己的负载均衡算法
 */
public class UserLoadBalance implements LoadBalance {

    @Override
    public <T> Invoker<T> select(List<Invoker<T>> invokers, URL url, Invocation invocation) throws RpcException {
        return getRandomSelected(invokers);
    }

    private final AtomicBoolean init = new AtomicBoolean(false);
    private Map<Integer,Invoker> invokerMap = new ConcurrentHashMap<>();

    public static volatile JsonObject first ;
    public static volatile JsonObject second;
    public static volatile JsonObject third ;
    public static  int score1=1,score2=1,score3=1;

    private <T> Invoker<T> getRandomSelected(List<Invoker<T>> invokers){
        if (!init.get()) {
            if (init.compareAndSet(false, true)) {
                for (Invoker<T> invoker : invokers) {
                    invokerMap.put(invoker.getUrl().getPort(), invoker);
                }
            }
        }
//        //选中端口号核心算法
        int port =getRandomPort();
        Invoker invoker = invokerMap.get(port);
        if(invoker != null){
            return invoker;
        }
        return invokers.get(ThreadLocalRandom.current().nextInt(invokers.size()));
    }

    /**
     * 依据json 里的数据，赋权重得到一个score
     * @return score
     */
    private void getScore() {
//
        int sta1=first.get("poolSize").getAsInt()*1+first.get("coreSize").getAsInt()*2+first.get("payLoad").getAsInt()*3+first.get("accepts").getAsInt()*4;
        int dyn1=first.get("freeMemory").getAsInt()*3+first.get("maxMemory").getAsInt()*2+first.get("avaliableProcessors").getAsInt();
        score1=2*sta1+3*dyn1;


        int sta2=second.get("poolSize").getAsInt()*1+second.get("coreSize").getAsInt()*2+second.get("payLoad").getAsInt()*3+second.get("accepts").getAsInt()*4;
        int dyn2=second.get("freeMemory").getAsInt()*3+second.get("maxMemory").getAsInt()*2+second.get("avaliableProcessors").getAsInt();
        score2=2*sta2+3*dyn2;

        int sta3=third.get("poolSize").getAsInt()*1+third.get("coreSize").getAsInt()*2+third.get("payLoad").getAsInt()*3+second.get("accepts").getAsInt()*4;
        int dyn3=third.get("freeMemory").getAsInt()*3+third.get("maxMemory").getAsInt()*2+third.get("avaliableProcessors").getAsInt();
        score3=2*sta3+3*dyn3;



//
    }


    private int getRandomPort() {
            //初始化为加权随机
            int index = ThreadLocalRandom.current().nextInt(score1 + score2 + score3);
            int port = getSelectedPort(score1, score2, score3, index);
            return port;

    }


    private int getSelectedPort(int score1, int score2, int score3, int index) {
        if(index>=0 && index < score1) return  20880;
        if(index>=score1 && index < score1+score2) return  20870;
        if(index>=score1+score2 && index < score1+score2+score3) return  20890;
        return 0;
    }

}
