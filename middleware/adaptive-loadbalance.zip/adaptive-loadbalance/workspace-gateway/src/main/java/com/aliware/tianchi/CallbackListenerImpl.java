package com.aliware.tianchi;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.dubbo.rpc.listener.CallbackListener;


/**
 * @author daofeng.xjf
 *
 * 客户端监听器
 * 可选接口
 * 用户可以基于获取获取服务端的推送信息，与 CallbackService 搭配使用
 *
 */
public class CallbackListenerImpl implements CallbackListener {

    @Override
    public void receiveServerMsg(String msg) {
        JsonObject jsonObject = new Gson().fromJson(msg, JsonObject.class);
        System.out.println("receive msg from server :" + jsonObject.toString());


        if(jsonObject!=null){
            int port = jsonObject.get("port").getAsInt();
            String info=jsonObject.get("info").getAsString();

            JsonObject infoObject = new JsonParser().parse(info).getAsJsonObject();
            if(port == 20880){
                UserLoadBalance.first = jsonObject;
            }
            if(port == 20870){
                UserLoadBalance.second = jsonObject;
            }
            if(port == 20890){
                UserLoadBalance.third = jsonObject;
            }

            /**
             *
             *
             *
             */





        }
    }

}
